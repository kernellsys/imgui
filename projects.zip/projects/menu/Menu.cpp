//============ Copyright ImMagic, All rights reserved ============//
//
// Purpose: 
//
//================================================================//

// STL
#include <string>

// Main
#include "Menu.h"
#include "Texture.h"
#include "TextEditor.h"

// Dear ImGui
#include "imgui/imgui.h"
#include "imgui/imgui_internal.h"

// Dear ImGui - Backends
#include "imgui/backends/imgui_impl_dx11.h"
#include "imgui/backends/imgui_impl_win32.h"

// Dear ImGui - Misc
#include "imgui/misc/imgui_freetype.h"

// Resources - Fonts
#include "Resources/fonts/font_montserrat_medium.h"
#include "Resources/fonts/font_exo2_medium.h"
#include "Resources/fonts/font_sf_pro_display_medium.h"
#include "Resources/fonts/font_poppins_medium.h"
#include "Resources/fonts/font_inter_semibold.h"
#include "Resources/fonts/font_inter_medium.h"
#include "Resources/fonts/font_ubuntu_regular.h"
#include "Resources/fonts/font_ubuntu_medium.h"
#include "Resources/fonts/font_cascadia_mono_pl_regular.h"

// Resources - Textures
#include "Resources/textures/menu/image_running.h"
#include "Resources/textures/menu/image_code.h"
#include "Resources/textures/menu/image_eye.h"
#include "Resources/textures/menu/image_misc.h"
#include "Resources/textures/menu/image_palette.h"
#include "Resources/textures/menu/image_settings.h"
#include "Resources/textures/menu/image_target.h"
#include "Resources/textures/menu/image_click.h"
#include "Resources/textures/menu/image_clock.h"
#include "Resources/textures/menu/image_crime.h"
#include "Resources/textures/menu/image_cursor.h"
#include "Resources/textures/menu/image_evil.h"
#include "Resources/textures/menu/image_globe.h"
#include "Resources/textures/menu/image_knife.h"
#include "Resources/textures/menu/image_location.h"
#include "Resources/textures/menu/image_objects.h"
#include "Resources/textures/menu/image_pulse.h"
#include "Resources/textures/menu/image_verified.h"
#include "Resources/textures/menu/image_wrench.h"
#include "Resources/textures/menu/image_clear.h"
#include "Resources/textures/menu/image_open.h"
#include "Resources/textures/menu/image_save.h"
#include "Resources/textures/menu/image_play.h"

// Definitions
#define PROJECT_NAME        "Zyrex"
#define PROJECT_VERSION     "1.2.3"
#define PROJECT_BUILD       __DATE__

bool Menu::Initialize(HWND hWnd, ID3D11Device* pDevice, ID3D11DeviceContext* pDeviceContext)
{
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();

    ImGuiStyle& style = ImGui::GetStyle();
    ImGuiIO& io = ImGui::GetIO(); (void)io;

    io.IniFilename = nullptr;   // Disable INI File

    // Setup Dear ImGui default style
    ImGui::StyleColorsDark();
    
    style.WindowRounding    = 7;
    style.ChildRounding     = 5;
    style.FrameRounding     = 4;
    style.PopupRounding     = 3;

    style.WindowBorderSize  = 1;
    style.ChildBorderSize   = 1;
    style.FrameBorderSize   = 0;
    style.PopupBorderSize   = 0;
    
    style.WindowPadding     = ImVec2(16, 16);
    style.ItemSpacing       = style.WindowPadding;
    
    style.ChildPadding      = ImVec2(14, 14);
    style.ItemInnerSpacing  = ImVec2(8, 6);
    
    style.FramePadding      = ImVec2(12, 12);
    style.CellPadding       = ImVec2(4, 2);

    style.ScrollbarSize     = 6.0f;
    style.GrabMinSize       = 14.0f;
    style.GrabRounding      = style.GrabMinSize / 2.0f;

    style.ButtonTextAlign   = ImVec2(0.5f, 0.5f);
    
    // Custom Theme Colors
    style.Colors[ImGuiCol_WindowBg]             = ImAdd::HexToColorVec4(0x0a0708); 
    style.Colors[ImGuiCol_ChildBg]              = ImAdd::HexToColorVec4(0x120f11, 0.6f);
    style.Colors[ImGuiCol_PopupBg]              = ImAdd::HexToColorVec4(0x120f11);
    style.Colors[ImGuiCol_TitleBg]              = ImAdd::HexToColorVec4(0x120f11);
    style.Colors[ImGuiCol_TitleBgActive]        = style.Colors[ImGuiCol_TitleBg];
    style.Colors[ImGuiCol_TitleBgCollapsed]     = style.Colors[ImGuiCol_TitleBg];

    style.Colors[ImGuiCol_Text]                 = ImAdd::HexToColorVec4(0xdadada);
    style.Colors[ImGuiCol_TextDisabled]         = ImAdd::HexToColorVec4(0x555555, 0.7f);
    style.Colors[ImGuiCol_CheckMark]            = ImAdd::HexToColorVec4(0xdadada);

    style.Colors[ImGuiCol_Border]               = ImAdd::HexToColorVec4(0x221c1e, 0.75f);
    style.Colors[ImGuiCol_Separator]            = style.Colors[ImGuiCol_Border];

    style.Colors[ImGuiCol_Header]               = ImAdd::HexToColorVec4(0x57beea);
    style.Colors[ImGuiCol_HeaderHovered]        = ImAdd::HexToColorVec4(0x007ac8);
    style.Colors[ImGuiCol_HeaderActive]         = ImAdd::HexToColorVec4(0x007ac8);

    style.Colors[ImGuiCol_SliderGrab]           = style.Colors[ImGuiCol_Header];
    style.Colors[ImGuiCol_SliderGrabActive]     = style.Colors[ImGuiCol_HeaderActive];
    style.Colors[ImGuiCol_TextSelectedBg]       = style.Colors[ImGuiCol_Header];
    style.Colors[ImGuiCol_TextSelectedBg].w     = 0.4f;

    style.Colors[ImGuiCol_FrameBg]              = ImAdd::HexToColorVec4(0x1a1617, 0.9f);
    style.Colors[ImGuiCol_FrameBgHovered]       = ImAdd::HexToColorVec4(0x221e1f, 0.9f);
    style.Colors[ImGuiCol_FrameBgActive]        = ImAdd::HexToColorVec4(0x151213, 0.9f);

    style.Colors[ImGuiCol_FrameBgShadow]        = ImVec4(0.00f, 0.00f, 0.00f, 0.45f); 
    style.Colors[ImGuiCol_ButtonShadow]         = ImVec4(0.00f, 0.00f, 0.00f, 0.45f);

    style.Colors[ImGuiCol_Button]               = style.Colors[ImGuiCol_FrameBg];
    style.Colors[ImGuiCol_ButtonHovered]        = style.Colors[ImGuiCol_FrameBgHovered];
    style.Colors[ImGuiCol_ButtonActive]         = style.Colors[ImGuiCol_FrameBgActive];

    style.Colors[ImGuiCol_Tab]                  = ImAdd::HexToColorVec4(0x0e0c0d);
    style.Colors[ImGuiCol_TabHovered]           = ImAdd::HexToColorVec4(0x1a1617);
    style.Colors[ImGuiCol_TabActive]            = ImAdd::HexToColorVec4(0x151213);

    // Setup Font
    ImFontConfig font_cfg_main;
    font_cfg_main.FontLoaderFlags = ImGuiFreeTypeLoaderFlags_ForceAutoHint;
    font_cfg_main.GlyphOffset = ImVec2(0, -1);
    font_cfg_main.SizePixels = 14.0f;
    io.Fonts->AddFontFromMemoryCompressedTTF(font_inter_semibold_compressed_data, font_inter_semibold_compressed_size, font_cfg_main.SizePixels, &font_cfg_main, io.Fonts->GetGlyphRangesDefault());
    
    ImFontConfig font_cfg_header;
    font_cfg_header.FontLoaderFlags = ImGuiFreeTypeLoaderFlags_ForceAutoHint;
    font_cfg_header.GlyphOffset = ImVec2(0, -1);
    font_cfg_header.SizePixels = 16.0f;
    io.Fonts->AddFontFromMemoryCompressedTTF(font_inter_semibold_compressed_data, font_inter_semibold_compressed_size, font_cfg_header.SizePixels, &font_cfg_header, io.Fonts->GetGlyphRangesDefault());

    ImFontConfig font_cfg_code;
    font_cfg_code.FontLoaderFlags = ImGuiFreeTypeLoaderFlags_ForceAutoHint;
    font_cfg_code.SizePixels = 14;
    io.Fonts->AddFontFromMemoryCompressedTTF(font_cascadia_mono_pl_regular_compressed_data, font_cascadia_mono_pl_regular_compressed_size, font_cfg_code.SizePixels, &font_cfg_code, io.Fonts->GetGlyphRangesDefault());
    
    // Initialize Dear ImGui - WIN32
    if (!ImGui_ImplWin32_Init(hWnd)) return false;

    // Initialize Dear ImGui - DX11
    if (!ImGui_ImplDX11_Init(pDevice, pDeviceContext)) return false;

    // Initialize Textures
    m_pIconRunning  = D3D11CreateTextureFromBytes(pDevice, running_bytes    , sizeof(running_bytes));
    m_pIconCode     = D3D11CreateTextureFromBytes(pDevice, code_bytes       , sizeof(code_bytes));
    m_pIconEye      = D3D11CreateTextureFromBytes(pDevice, eye_bytes        , sizeof(eye_bytes));
    m_pIconMisc     = D3D11CreateTextureFromBytes(pDevice, misc_bytes       , sizeof(misc_bytes));
    m_pIconPalette  = D3D11CreateTextureFromBytes(pDevice, palette_bytes    , sizeof(palette_bytes));
    m_pIconSettings = D3D11CreateTextureFromBytes(pDevice, settings_bytes   , sizeof(settings_bytes));
    m_pIconTarget   = D3D11CreateTextureFromBytes(pDevice, target_bytes     , sizeof(target_bytes));
    m_pIconClick	= D3D11CreateTextureFromBytes(pDevice, click_bytes      , sizeof(click_bytes));
    m_pIconClock	= D3D11CreateTextureFromBytes(pDevice, clock_bytes      , sizeof(clock_bytes));
    m_pIconCrime	= D3D11CreateTextureFromBytes(pDevice, crime_bytes      , sizeof(crime_bytes));
    m_pIconCursor	= D3D11CreateTextureFromBytes(pDevice, cursor_bytes     , sizeof(cursor_bytes));
    m_pIconEvil		= D3D11CreateTextureFromBytes(pDevice, evil_bytes       , sizeof(evil_bytes));
    m_pIconGlobe	= D3D11CreateTextureFromBytes(pDevice, globe_bytes      , sizeof(globe_bytes));
    m_pIconKnife	= D3D11CreateTextureFromBytes(pDevice, knife_bytes      , sizeof(knife_bytes));
    m_pIconLocation	= D3D11CreateTextureFromBytes(pDevice, location_bytes   , sizeof(location_bytes));
    m_pIconObjects	= D3D11CreateTextureFromBytes(pDevice, objects_bytes    , sizeof(objects_bytes));
    m_pIconPulse	= D3D11CreateTextureFromBytes(pDevice, pulse_bytes      , sizeof(pulse_bytes));
    m_pIconVerified	= D3D11CreateTextureFromBytes(pDevice, verified_bytes   , sizeof(verified_bytes));
    m_pIconWrench	= D3D11CreateTextureFromBytes(pDevice, wrench_bytes     , sizeof(wrench_bytes));
    m_pIconClear    = D3D11CreateTextureFromBytes(pDevice, clear_bytes      , sizeof(clear_bytes));
    m_pIconSave     = D3D11CreateTextureFromBytes(pDevice, save_bytes       , sizeof(save_bytes));
    m_pIconOpen     = D3D11CreateTextureFromBytes(pDevice, open_bytes       , sizeof(open_bytes));
    m_pIconRun      = D3D11CreateTextureFromBytes(pDevice, play_bytes       , sizeof(play_bytes));

    m_Scripts = {
       { "radar_hack.lua", "C:\\\\users\\admin\\documents\\Ronin\\Scripts" },
       { "spectator_list.lua", "C:\\\\users\\admin\\documents\\Ronin\\Scripts" },
       { "auto_jump.lua", "C:\\\\users\\admin\\documents\\Ronin\\Scripts" },
       { "anti_aim.lua", "C:\\\\users\\admin\\documents\\Ronin\\Scripts" },
       { "anti_troll.lua", "C:\\\\users\\admin\\documents\\Ronin\\Scripts" }
    };

    m_Tabs = {
        {
            "Combat", m_pIconTarget, 0,
            {
                { "Legit", m_pIconVerified },
                { "Silent", m_pIconClick },
                { "Aimbot", m_pIconCursor },
                { "Trigger", m_pIconClock }
            }
        },

        {
            "Visuals", m_pIconEye, 0,
            {
                { "World", m_pIconGlobe },
                { "Local", m_pIconLocation },
                { "ESP", m_pIconObjects },
                { "Visualizers", m_pIconPulse }
            }
        },

        {
            "Skin Changer", m_pIconPalette, 0,
            {
                { "Skins", m_pIconCrime },
                { "Knives", m_pIconKnife },
                { "Custom", m_pIconWrench }
            }
        },

        {
            "Movement", m_pIconRunning, 0,
            {
                { "Legit", m_pIconVerified },
                { "Rage", m_pIconEvil }
            }
        },

        {
            "Misc", m_pIconMisc, 0,
            {
            }
        },

        {
            "Lua", m_pIconCode, 0,
            {
            }
        },

        {
            "Settings", m_pIconCode, 0,
            {
            }
        },
    };

    m_pTextEditor = new CTextEditor();
    m_pTextEditor->SetLanguageDefinition(CTextEditor::LanguageDefinitionId::Lua);
    m_pTextEditor->SetPalette(CTextEditor::PaletteId::Dark);

    m_bInitialized = true;

    return true;
}

void Menu::Render()
{
    if (!m_bInitialized) return;

    ImGui_ImplDX11_NewFrame();
    ImGui_ImplWin32_NewFrame();
    ImGui::NewFrame();
    {
        DrawMenu();
    }
    ImGui::Render();
    ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
}

void Menu::DrawMenu()
{
    ImGuiStyle& style = ImGui::GetStyle();
    ImGuiIO& io = ImGui::GetIO(); (void)io;

    ImGui::SetNextWindowSize(ImVec2(760, 554), ImGuiCond_Once);
    ImGui::SetNextWindowPos(io.DisplaySize / 2, ImGuiCond_Once, ImVec2(0.5f, 0.5f));

    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0);
    bool main_window = ImGui::Begin("ImMagic - Menu", (bool*)0, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse);
    ImGui::PopStyleVar(2);

    if (main_window)
    {
        float header_padding = style.WindowPadding.y;
        float header_height = io.Fonts->Fonts[Font::Header]->LegacySize + header_padding * 2.0f;
        static float sidebar_width = 180.0f;
        
        ImRect window_bb(ImGui::GetCurrentWindow()->Rect());
        ImRect header_bb(window_bb.Min, ImVec2(window_bb.Max.x, window_bb.Min.y + header_height));
        ImRect content_bb(ImVec2(window_bb.Min.x, header_bb.Max.y), window_bb.Max);

        if (ImGui::GetCurrentWindow()->Flags & ImGuiWindowFlags_NoBackground)
        {
            ImGuiWindow* window = ImGui::GetCurrentWindow();

            window->DrawList->AddRectFilled(header_bb.Min, header_bb.Max, ImGui::GetColorU32(ImGuiCol_TitleBg), style.WindowRounding, ImDrawFlags_RoundCornersTop);
            window->DrawList->AddRectFilled(content_bb.Min, content_bb.Max, ImGui::GetColorU32(ImGuiCol_WindowBg), style.WindowRounding, ImDrawFlags_RoundCornersBottom);

            if (style.WindowBorderSize > 0.0f)
            {
                //window->DrawList->AddRect(window_bb.Min, window_bb.Max, ImGui::GetColorU32(ImGuiCol_Border), style.WindowRounding - (style.WindowBorderSize > 0 ? (style.WindowBorderSize + 1.0f) : 0.0f), 0, style.WindowBorderSize);
                window->DrawList->AddLine(ImVec2(header_bb.Min.x, header_bb.Max.y - style.WindowBorderSize), ImVec2(header_bb.Max.x, header_bb.Max.y - style.WindowBorderSize), ImGui::GetColorU32(ImGuiCol_Border), style.WindowBorderSize);
            }
        }

        ImGui::SetCursorScreenPos(header_bb.Min);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(header_padding, header_padding));
        if (ImGui::BeginChild("header", header_bb.GetSize(), ImGuiChildFlags_AlwaysUseWindowPadding, ImGuiWindowFlags_NoBackground))
        {
            ImGui::PushFont(io.Fonts->Fonts[Font::Header]);

            ImGui::Text(PROJECT_NAME);
            ImGui::SameLine(ImGui::GetWindowWidth() - ImGui::GetFontSize() - style.WindowPadding.x);
            ImAdd::ButtonXMark("close-button", ImVec2(ImGui::GetFontSize(), ImGui::GetFontSize()));

            ImGui::PopFont();
        }
        ImGui::EndChild();
        ImGui::PopStyleVar();

        ImGui::SetCursorScreenPos(content_bb.Min);
        if (ImGui::BeginChild("content", content_bb.GetSize(), ImGuiChildFlags_None, ImGuiWindowFlags_NoBackground))
        {
            ImGui::SetCursorScreenPos(ImGui::GetWindowPos() + style.WindowPadding);
            if (ImGui::BeginChild("menubar", ImVec2(ImGui::GetWindowWidth() - style.WindowPadding.x * 2.0f, ImGui::GetFrameHeight()), ImGuiChildFlags_None, ImGuiWindowFlags_NoBackground))
            {
                ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, style.ChildBorderSize);

                for (int i = 0; i < m_Tabs.size() - 1; i++)
                {
                    auto& tab = m_Tabs[i];

                    ImAdd::TabIcon(tab.icon, tab.label, &m_iCurrentPage, i, true);
                    if (i < (m_Tabs.size() - 1)) ImGui::SameLine();
                }

                ImGui::PopStyleVar();

                ImGui::SameLine(ImGui::GetWindowWidth() - ImGui::GetFrameHeight());
                ImAdd::TabIcon(m_pIconSettings, "##Settings", &m_iCurrentPage, m_Tabs.size() - 1);
            }
            ImGui::EndChild();

            bool has_subtabs = !m_Tabs[m_iCurrentPage].subtabs.empty();

            if (has_subtabs)
            {
                ImGui::SetCursorScreenPos(ImGui::GetWindowPos() + ImVec2(0.0f, ImGui::GetFrameHeight() + style.WindowPadding.y));
                if (ImAdd::BeginChild("sidebar", ImVec2(sidebar_width, ImGui::GetWindowHeight() - ImGui::GetFrameHeight() - style.WindowPadding.y), false))
                {
                    auto& tab = m_Tabs[m_iCurrentPage];
                    auto& subtabs = tab.subtabs;

                    ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(style.ItemSpacing.x, style.FrameRounding));
                    ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, style.ChildBorderSize);

                    for (int i = 0; i < subtabs.size(); i++)
                    {
                        auto& subtab = subtabs[i];

                        ImAdd::TabIcon(subtab.icon, subtab.label, &tab.selected_subtab, i, false, ImVec2(ImGui::GetContentRegionAvail().x, 0.0f));
                    }

                    ImGui::PopStyleVar(2);
                }
                ImAdd::EndChild();
            }

            ImGui::SetCursorScreenPos(ImGui::GetWindowPos() + ImVec2(has_subtabs ? (sidebar_width - style.WindowPadding.x) : 0.0f, ImGui::GetFrameHeight() + style.WindowPadding.y));
            if (ImAdd::BeginChild(std::string("page:" + std::to_string(m_iCurrentPage) + ":" + std::to_string(m_Tabs[m_iCurrentPage].selected_subtab)).c_str(), ImVec2(has_subtabs ? (ImGui::GetWindowWidth() - sidebar_width + style.WindowPadding.x) : ImGui::GetWindowWidth(), ImGui::GetWindowHeight() - ImGui::GetFrameHeight() - style.WindowPadding.y), false))
            {
                float group_width = ImTrunc((ImGui::GetContentRegionAvail().x - style.ItemSpacing.x) / 2);

                if (m_iCurrentPage == 0)
                {
                    if (m_Tabs[m_iCurrentPage].selected_subtab == 0)
                    {
                        ImGui::BeginGroup();

                        static bool bEnabled = false;
                        static bool bPredictAim = false;
                        static bool bAutoGroup = false;
                        static bool bVisibleCheck = false;
                        static bool bFlashCheck = false;
                        static bool bScopeCheck = false;
                        static bool bHumanizedSmooth = false;
                        static bool bHitChance = false;

                        if (ImAdd::BeginChild("1", ImVec2(group_width, io.Fonts->Fonts[Font::Header]->LegacySize + ImGui::GetFontSize() * 7 + style.CellPadding.y * 16 + style.ChildPadding.y * 9)))
                        {
                            ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, style.ChildBorderSize);
                            ImGui::PushFont(io.Fonts->Fonts[Font::Header]);
                            ImAdd::ToggleButton("Legit", &bEnabled);
                            ImGui::PopFont();
                            ImGui::PopStyleVar();

                            if (bEnabled) {
                                ImAdd::CheckBox("Predict aim", &bPredictAim);
                                ImAdd::CheckBox("Auto group", &bAutoGroup);
                                ImAdd::CheckBox("Visible check", &bVisibleCheck);
                                ImAdd::CheckBox("Flash check", &bFlashCheck);
                                ImAdd::CheckBox("Scope check", &bScopeCheck);
                                ImAdd::CheckBox("Humanized smooth", &bHumanizedSmooth);
                                ImAdd::CheckBox("Hit chance", &bHitChance);
                            }
                        }
                        ImGui::EndChild();

                        static int iHumanizedSmooth = 30;
                        static int iHitChance = 70;

                        if (ImAdd::BeginChild("2", ImVec2(group_width, ImGui::GetFontSize() * 4 + style.ItemInnerSpacing.y * 2.0f + style.ChildPadding.y * 3.0f)))
                        {
                            ImAdd::SliderInt("Humanized Smoothness", &iHumanizedSmooth, 0, 100, "%d%%");
                            ImAdd::SliderInt("Hit chance##slider", &iHitChance, 0, 100, "%d%%");
                        }
                        ImGui::EndChild();

                        ImGui::EndGroup();
                        ImGui::SameLine();

                        static bool bDrawFOV = false;

                        static bool bDrawCircleOutlines = false;
                        static bool bDrawCircleFilled = false;
                        static bool bDrawCenterTracer = false;
                        static bool bDrawRecoilCircle = false;

                        static ImVec4 ColCircleOutlines = ImVec4(0, 0, 1, 1);
                        static ImVec4 ColCircleFilled = ImVec4(0, 0, 1, 0.5f);
                        static ImVec4 ColCenterTracer = ImVec4(0, 1, 0, 1);
                        static ImVec4 ColRecoilCircle = ImVec4(1, 0, 0, 0.75f);

                        static float fLineThichness = 1.0f;

                        if (ImAdd::BeginChild("3", ImVec2(0, 0)))
                        {
                            ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, style.ChildBorderSize);
                            ImGui::PushFont(io.Fonts->Fonts[Font::Header]);
                            ImAdd::ToggleButton("Draw FOV", &bDrawFOV);
                            ImGui::PopFont();
                            ImGui::PopStyleVar();

                            ImAdd::SeparatorText("Render");

                            ImAdd::CheckBox("Draw circle outlines", &bDrawCircleOutlines);
                            ImAdd::CheckBox("Draw circle filled", &bDrawCircleFilled);
                            ImAdd::CheckBox("Draw center tracer", &bDrawCenterTracer);
                            ImAdd::CheckBox("Draw recoil circle", &bDrawRecoilCircle);

                            ImAdd::SeparatorText("Colors");

                            ImAdd::ColorEdit4("Circle outlines", (float*)&ColCircleOutlines);
                            ImAdd::ColorEdit4("Circle filled", (float*)&ColCircleFilled);
                            ImAdd::ColorEdit4("Center tracer", (float*)&ColCenterTracer);
                            ImAdd::ColorEdit4("Recoil circle", (float*)&ColRecoilCircle);

                            ImAdd::SeparatorText("Configs");

                            ImAdd::SliderFloat("Line thichness", &fLineThichness, 0.5f, 3.0f, "%.1fpx");
                        }
                        ImGui::EndChild();
                    }
                    else
                    {
                        // check for other subtabs
                    }
                }
                else if (m_iCurrentPage == 1)
                {
                    if (ImAdd::BeginChild("others", ImVec2(group_width, 0.0f)))
                    {
                        static int iMainTarget = 0;
                        static int iAimMode = 0;

                        ImAdd::SeparatorText("Combo");

                        ImAdd::Combo("Main target", &iMainTarget, { "Header", "Body", "Limbs" });
                        ImAdd::Combo("Aim mode", &iAimMode, { "Legit", "Rage", "Bot" });

                        ImGui::Spacing();
                        ImAdd::SeparatorText("Keybind");

                        static ImGuiKey keybind = ImGuiKey_Insert;

                        ImAdd::KeyBind("Keybind", &keybind);
                    }
                    ImAdd::EndChild();
                }
                else if (m_iCurrentPage == 2)
                {

                }
                else if (m_iCurrentPage == 3)
                {

                }
                else if (m_iCurrentPage == 4)
                {

                }
                else if (m_iCurrentPage == 5)
                {
                    static float explorer_width = 230.0f;

                    static int selected_script_index = -1;

                    if (ImGui::BeginChild("left-frame", ImVec2(ImGui::GetWindowWidth() - explorer_width - style.ItemSpacing.x - style.WindowPadding.x * 2.0f, 0.0f), ImGuiChildFlags_None, ImGuiWindowFlags_NoBackground))
                    {
                        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, style.FramePadding);
                        if (ImGui::BeginChild("path", ImVec2(0.0f, ImGui::GetFrameHeight()), ImGuiChildFlags_Border))
                        {
                            if (selected_script_index == -1)
                            {
                                ImGui::Text("Please select a script");
                            }
                            else
                            {
                                ImGui::Image(m_pIconOpen, ImVec2(ImGui::GetFontSize(), ImGui::GetFontSize()), ImVec2(0, 0), ImVec2(1, 1), style.Colors[ImGuiCol_SliderGrab], ImVec4());
                                ImGui::SameLine(ImGui::GetWindowHeight());
                                ImGui::Text("%s\\%s", m_Scripts[selected_script_index].dir, m_Scripts[selected_script_index].file);
                            }
                        }
                        ImGui::EndChild();
                        ImGui::PopStyleVar();

                        if (ImAdd::BeginChild("editor-frame", ImVec2(0, ImGui::GetWindowHeight() - ImGui::GetFrameHeight() * 2.0f - style.ItemSpacing.y * 2.0f)))
                        {
                            ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, ImGui::GetFontSize() / 2));
                            ImGui::PushFont(io.Fonts->Fonts[Font::Code]);

                            m_pTextEditor->Render("editor-widget", false, ImVec2(0, 0), true);

                            ImGui::PopFont();
                            ImGui::PopStyleVar();
                        }
                        ImAdd::EndChild();
                        if (ImGui::BeginChild("editor-controls", ImVec2(0, 0), ImGuiChildFlags_None, ImGuiWindowFlags_NoBackground))
                        {
                            ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, style.ChildBorderSize);

                            ImAdd::Button(m_pIconClear, "Clear");
                            ImGui::SameLine();
                            ImAdd::Button(m_pIconOpen, "Open");
                            ImGui::SameLine();
                            ImAdd::Button(m_pIconSave, "Save");

                            ImGui::SameLine(ImGui::GetWindowWidth() - ImGui::CalcTextSize("Execute").x - ImGui::GetFontSize() - style.FramePadding.x * 3.0f);
                            ImAdd::Button(m_pIconRun, "Execute");

                            ImGui::PopStyleVar();
                        }
                        ImGui::EndChild();
                    }
                    ImGui::EndChild();

                    ImGui::SameLine();

                    if (ImAdd::BeginChild("Explorer", ImVec2(explorer_width, 0.0f)))
                    {
                        ImAdd::SeparatorText("Explorer");

                        for (int i = 0; i < m_Scripts.size(); i++)
                        {
                            auto& script = m_Scripts[i];

                            if (ImAdd::SelectableLabel(script.file, i == selected_script_index, false, ImVec2(ImGui::GetContentRegionAvail().x, 0))) selected_script_index = i;
                        }
                    }
                    ImAdd::EndChild();
                }
                else if (m_iCurrentPage == 6)
                {
                    if (ImAdd::BeginChild("Theme"))
                    {
                        ImAdd::ColorEdit4("Accent"              , (float*)&style.Colors[ImGuiCol_Header]);
                        ImAdd::ColorEdit4("Accent hovered"      , (float*)&style.Colors[ImGuiCol_HeaderHovered]);
                        ImAdd::ColorEdit4("Accent active"       , (float*)&style.Colors[ImGuiCol_HeaderActive]);
                        ImAdd::ColorEdit4("Text"                , (float*)&style.Colors[ImGuiCol_Text]);
                        ImAdd::ColorEdit4("Text disabled"       , (float*)&style.Colors[ImGuiCol_TextDisabled]);
                        ImAdd::ColorEdit4("Button"              , (float*)&style.Colors[ImGuiCol_Button]);
                        ImAdd::ColorEdit4("Button hovered"      , (float*)&style.Colors[ImGuiCol_ButtonHovered]);
                        ImAdd::ColorEdit4("Button active"       , (float*)&style.Colors[ImGuiCol_ButtonActive]);
                        ImAdd::ColorEdit4("Frame"               , (float*)&style.Colors[ImGuiCol_FrameBg]);
                        ImAdd::ColorEdit4("Frame hovered"       , (float*)&style.Colors[ImGuiCol_FrameBgHovered]);
                        ImAdd::ColorEdit4("Frame active"        , (float*)&style.Colors[ImGuiCol_FrameBgActive]);
                        ImAdd::ColorEdit4("Title"               , (float*)&style.Colors[ImGuiCol_TitleBg]);
                        ImAdd::ColorEdit4("Border"              , (float*)&style.Colors[ImGuiCol_Border]);
                        ImAdd::ColorEdit4("Window"              , (float*)&style.Colors[ImGuiCol_WindowBg]);
                        ImAdd::ColorEdit4("Child"               , (float*)&style.Colors[ImGuiCol_ChildBg]);
                        ImAdd::ColorEdit4("Popup"               , (float*)&style.Colors[ImGuiCol_PopupBg]);
                        
                        // Update linked colors
                        style.Colors[ImGuiCol_Button]               = style.Colors[ImGuiCol_FrameBg];
                        style.Colors[ImGuiCol_ButtonHovered]        = style.Colors[ImGuiCol_FrameBgHovered];
                        style.Colors[ImGuiCol_ButtonActive]         = style.Colors[ImGuiCol_FrameBgActive];
                        style.Colors[ImGuiCol_TitleBgActive]        = style.Colors[ImGuiCol_TitleBg];
                        style.Colors[ImGuiCol_TitleBgCollapsed]     = style.Colors[ImGuiCol_TitleBg];
                        style.Colors[ImGuiCol_Separator]            = style.Colors[ImGuiCol_Border];
                        style.Colors[ImGuiCol_SliderGrab]           = style.Colors[ImGuiCol_Header];
                        style.Colors[ImGuiCol_SliderGrabActive]     = style.Colors[ImGuiCol_HeaderActive];
                        style.Colors[ImGuiCol_TextSelectedBg]       = style.Colors[ImGuiCol_Header];
                        style.Colors[ImGuiCol_TextSelectedBg].w     = 0.4f;
                    }
                    ImAdd::EndChild();
                }
                else
                {

                }
            }
            ImAdd::EndChild();
        }
        ImGui::EndChild();
    }
    ImGui::End();
}

void Menu::Shutdown()
{
    if (!m_bInitialized) return;

    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();

    if (m_pTextEditor)
    {
        delete m_pTextEditor;
        m_pTextEditor = nullptr;
    }

    if (m_pIconRunning)     { m_pIconRunning->Release();    m_pIconRunning = nullptr; }
    if (m_pIconCode)        { m_pIconCode->Release();       m_pIconCode = nullptr; }
    if (m_pIconEye)         { m_pIconEye->Release();        m_pIconEye = nullptr; }
    if (m_pIconMisc)        { m_pIconMisc->Release();       m_pIconMisc = nullptr; }
    if (m_pIconPalette)     { m_pIconPalette->Release();    m_pIconPalette = nullptr; }
    if (m_pIconSettings)    { m_pIconSettings->Release();   m_pIconSettings = nullptr; }
    if (m_pIconClick)       { m_pIconClick->Release();      m_pIconClick = nullptr; }
    if (m_pIconClock)       { m_pIconClock->Release();      m_pIconClock = nullptr; }
    if (m_pIconCrime)       { m_pIconCrime->Release();      m_pIconCrime = nullptr; }
    if (m_pIconEvil)        { m_pIconEvil->Release();       m_pIconEvil = nullptr; }
    if (m_pIconGlobe)       { m_pIconGlobe->Release();      m_pIconGlobe = nullptr; }
    if (m_pIconKnife)       { m_pIconKnife->Release();      m_pIconKnife = nullptr; }
    if (m_pIconLocation)    { m_pIconLocation->Release();   m_pIconLocation = nullptr; }
    if (m_pIconObjects)     { m_pIconObjects->Release();    m_pIconObjects = nullptr; }
    if (m_pIconPulse)       { m_pIconPulse->Release();      m_pIconPulse = nullptr; }
    if (m_pIconVerified)    { m_pIconVerified->Release();   m_pIconVerified = nullptr; }
    if (m_pIconWrench)      { m_pIconWrench->Release();     m_pIconWrench = nullptr; }
    if (m_pIconTarget)      { m_pIconTarget->Release();     m_pIconTarget = nullptr; }
    if (m_pIconCursor)      { m_pIconCursor->Release();     m_pIconCursor = nullptr; }
    if (m_pIconClear)       { m_pIconClear->Release();      m_pIconClear = nullptr; }
    if (m_pIconSave)        { m_pIconSave->Release();       m_pIconSave = nullptr; }
    if (m_pIconOpen)        { m_pIconOpen->Release();       m_pIconOpen = nullptr; }
    if (m_pIconRun)         { m_pIconRun->Release();        m_pIconRun = nullptr; }

    m_bInitialized = false;
}

void Menu::InvalidateDeviceObjects()
{
    if (!m_bInitialized) return;

    ImGui_ImplDX11_InvalidateDeviceObjects();
}

void Menu::CreateDeviceObjects()
{
    if (!m_bInitialized) return;

    ImGui_ImplDX11_CreateDeviceObjects();
}

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
bool Menu::HandleMessage(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    if (!m_bInitialized) return false;

#if 0
    if (uMsg == WM_KEYDOWN && wParam == VK_DELETE)
    {
        // Toggle menu

        return true; // important, incase we trying to close the menu while selecting an input, delete wont cause the content to be erased
    }
#endif

    return ImGui_ImplWin32_WndProcHandler(hWnd, uMsg, wParam, lParam);
}
